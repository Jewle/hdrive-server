export { default } from './AutoScroll.js';
